/**
 * @name X-02 Custom Type
 * @description A custom BetterDiscord typing plugin using a soft X-02 theme typing sound.
 * @version 1.2
 */

const typingSoundUrl = "https://github.com/Cherodactyl/x-02-custom-Type/raw/refs/heads/main/select.mp3";

module.exports = class X02CustomType {
    start() {
        this.keyHandler = this.playSound.bind(this);
        document.addEventListener("keydown", this.keyHandler);
    }

    stop() {
        document.removeEventListener("keydown", this.keyHandler);
    }

    playSound(e) {
        if (e.isComposing || e.key.length > 1) return;  // Ignore non-character keys
        const audio = new Audio(typingSoundUrl);
        audio.volume = 0.4;
        audio.play().catch(console.error);
    }
};
